# Flappy Bird Learning Environment

A small Flappy Bird-style game built with Python and Pygame. It uses original
geometric graphics and contains **no AI or learning code**. The simulation
environment can be imported and controlled with Python actions.

## Project structure

```text
flappy-bird/
├── game/
│   ├── __init__.py
│   ├── bird.py
│   ├── pipe.py
│   ├── environment.py
│   └── renderer.py
├── tests/
│   └── test_environment.py
├── main.py
├── requirements.txt
└── README.md
```

## Installation

Python 3.9+ is recommended.

```bash
cd flappy-bird
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
```

## Human gameplay

```bash
python main.py
```

- Press **Space** to start and jump.
- Press **Space** again to jump during play.
- After a collision, press **R** or **Space** to restart.
- Press **Esc** or close the window to quit.

## Simulation mode

Run a headless episode (no Pygame window and no frame-rate cap):

```bash
python main.py --mode simulation --seed 42
```

Show the simulation at a controlled display rate:

```bash
python main.py --mode simulation --render --fps 120 --speed 1.0 --seed 42
```

`--speed` scales the rendering loop's target FPS. It does not alter the
physics or the number of simulation frames per call to `step()`.

## Importing the environment

```python
from game import FlappyBirdEnvironment

env = FlappyBirdEnvironment(seed=42)  # render_mode=None means headless
observation, info = env.reset()

while True:
    action = 0  # 0 = do nothing, 1 = jump; supplied by your own controller
    observation, reward, terminated, truncated, info = env.step(action)

    if terminated or truncated:
        print("Final score:", info["score"])
        break

env.close()
```

Each call to `step()` advances the game by exactly one frame. You can create
multiple independent instances:

```python
env_a = FlappyBirdEnvironment(seed=1)
env_b = FlappyBirdEnvironment(seed=2)
obs_a, _ = env_a.reset()
obs_b, _ = env_b.reset()
```

Each instance owns its own random-number generator, bird, pipes, score, and
optional renderer. For parallel execution, keep rendering disabled and run
each instance in a separate worker/process as appropriate for your program.

## Environment API

### `FlappyBirdEnvironment(...)`

Important arguments:

- `width=480`, `height=640`: window and world dimensions in pixels.
- `seed=None`: optional seed for repeatable pipe-gap generation.
- `render_mode=None`: headless by default; use `"human"` to enable rendering.
- `pipe_speed=3.0`, `pipe_gap=170`, `pipe_width=72`, `pipe_spacing=220`.
- `max_steps=None`: optional episode frame limit. Reaching it sets
  `truncated=True` if the bird has not died.

### `reset(seed=None)`

Resets the episode and returns:

```python
observation, info
```

Pass a seed to restart the random sequence reproducibly.

### `step(action)`

Accepts exactly one of:

- `0`: do nothing.
- `1`: jump.

Returns:

```python
observation, reward, terminated, truncated, info
```

- `observation`: five normalized floats described below.
- `reward`: `+1.0` for each pipe pair passed, `-1.0` for death, otherwise `0.0`.
  If passing a pipe and dying happen on the same frame, both reward events
  are applied.
- `terminated`: `True` when the bird hits a pipe or the top/bottom boundary.
- `truncated`: `True` when the optional `max_steps` limit is reached before death.
- `info`: dictionary containing `score`, `steps`, and `collision`.

Calling `step()` after termination or truncation raises `RuntimeError`; call
`reset()` first. Invalid actions raise `ValueError`.

### Observation format

The observation is a tuple of five Python floats, always in this order:

| Index | Name | Meaning | Normalization |
|---:|---|---|---|
| 0 | `bird_y` | Bird center's vertical position | `y / screen_height`, clipped to `[0, 1]` |
| 1 | `bird_velocity` | Vertical velocity; negative means rising | `velocity_y / 12`, clipped to `[-1, 1]` |
| 2 | `pipe_distance` | Horizontal distance from bird center to next pipe's left edge | `distance / screen_width`, clipped to `[0, 1]` |
| 3 | `gap_center_y` | Vertical center of the next pipe opening | `gap_center_y / screen_height`, clipped to `[0, 1]` |
| 4 | `gap_height` | Height of the next pipe opening | `gap_height / screen_height`, clipped to `[0, 1]` |

Image coordinates start at the top-left: y increases downward. Therefore,
negative bird velocity means the bird is moving upward. Values are normalized
against the environment dimensions, making the representation scale-aware.

### `render()` and `close()`

`render()` draws the current state only when `render_mode="human"`. Rendering
is lazy, so headless environments do not initialize Pygame's display system.
`close()` releases the window resources.

## Tests

Run the included checks:

```bash
python -m unittest discover -s tests -v
```

The tests cover the step return contract, gravity, jump velocity, reset,
invalid actions, headless rendering, and independent environment instances.

## Design notes

- Physics and state updates live in `environment.py`, `bird.py`, and `pipe.py`.
- Pygame drawing is isolated in `renderer.py`.
- The environment advances only when `step()` is called; rendering never
  advances physics.
- Every environment has its own `random.Random` instance. Supplying the same
  seed and repeating the same actions reproduces pipe generation.
- The game uses circles and rectangles rather than external copyrighted art.
