"""Small standard-library test suite: python -m unittest discover -s tests."""

import unittest

from game import FlappyBirdEnvironment


class EnvironmentTests(unittest.TestCase):
    def test_step_contract_and_independent_instances(self):
        first = FlappyBirdEnvironment(seed=10)
        second = FlappyBirdEnvironment(seed=10)
        result = first.step(0)
        self.assertEqual(len(result), 5)
        observation, reward, terminated, truncated, info = result
        self.assertEqual(len(observation), 5)
        self.assertIsInstance(reward, float)
        self.assertFalse(terminated)
        self.assertFalse(truncated)
        self.assertEqual(info["steps"], 1)
        first.close()
        second.close()

    def test_gravity_and_jump(self):
        env = FlappyBirdEnvironment(seed=1)
        initial_y = env.bird.y
        env.step(0)
        self.assertGreater(env.bird.y, initial_y)
        env.reset()
        env.step(1)
        self.assertLess(env.bird.velocity_y, 0)
        env.close()

    def test_reset(self):
        env = FlappyBirdEnvironment(seed=2)
        env.step(1)
        observation, info = env.reset(seed=2)
        self.assertEqual(info["steps"], 0)
        self.assertEqual(info["score"], 0)
        self.assertEqual(env.bird.y, env.height * 0.5)
        self.assertEqual(len(observation), 5)
        env.close()

    def test_invalid_action(self):
        env = FlappyBirdEnvironment()
        with self.assertRaises(ValueError):
            env.step(2)
        env.close()

    def test_render_can_be_disabled(self):
        env = FlappyBirdEnvironment(render_mode=None)
        env.render()
        self.assertIsNone(env.renderer)
        env.close()


if __name__ == "__main__":
    unittest.main()
