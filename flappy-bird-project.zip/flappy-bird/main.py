"""Run the game in human mode or as a program-controlled simulation."""

import argparse
import pygame

from game import FlappyBirdEnvironment


def run_human():
    env = FlappyBirdEnvironment(render_mode="human")
    renderer = None
    started = False
    running = True
    try:
        # Creating the renderer also creates the Pygame window.
        env.render()
        renderer = env.renderer
        renderer.draw_start_screen()

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_SPACE:
                        if not started or env.terminated:
                            env.reset()
                            started = True
                        else:
                            env.bird.jump()
                    elif event.key == pygame.K_r and env.terminated:
                        env.reset()
                        started = True

            if started and not env.terminated:
                # The human loop advances the same physics as step(0).
                env.step(0)
            if started:
                env.render()
            else:
                renderer.draw_start_screen()
            renderer.tick(60)
    finally:
        env.close()


def run_simulation(render=False, fps=120, speed=1.0, seed=None):
    env = FlappyBirdEnvironment(
        seed=seed,
        render_mode="human" if render else None,
    )
    action = 0  # Demonstration controller: no input; this is not an AI.
    try:
        observation, info = env.reset(seed=seed)
        print("Simulation started. Initial observation:", observation)
        while True:
            observation, reward, terminated, truncated, info = env.step(action)
            if render:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        return
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                        return
                env.render()
                env.renderer.tick(max(1, int(fps * speed)))
            if terminated or truncated:
                print(f"Episode ended: score={info['score']}, steps={info['steps']}")
                break
    finally:
        env.close()


def main():
    parser = argparse.ArgumentParser(description="Flappy Bird game environment")
    parser.add_argument("--mode", choices=("human", "simulation"), default="human")
    parser.add_argument("--render", action="store_true",
                        help="show the window in simulation mode")
    parser.add_argument("--fps", type=int, default=120,
                        help="simulation render frame rate")
    parser.add_argument("--speed", type=float, default=1.0,
                        help="simulation speed multiplier when rendering")
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()

    if args.mode == "human":
        run_human()
    else:
        run_simulation(args.render, args.fps, args.speed, args.seed)


if __name__ == "__main__":
    main()
