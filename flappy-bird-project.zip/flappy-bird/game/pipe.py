"""Pipe pair model and collision geometry."""

class Pipe:
    def __init__(self, x, gap_y, gap_size, width, screen_height, speed):
        self.x = float(x)
        self.gap_y = float(gap_y)  # center of the opening
        self.gap_size = float(gap_size)
        self.width = int(width)
        self.screen_height = int(screen_height)
        self.speed = float(speed)
        self.scored = False

    @property
    def gap_top(self):
        return self.gap_y - self.gap_size / 2

    @property
    def gap_bottom(self):
        return self.gap_y + self.gap_size / 2

    @property
    def right(self):
        return self.x + self.width

    def update(self):
        self.x -= self.speed

    def collides_with_circle(self, bird):
        left, top, right, bottom = bird.bounds
        overlaps_x = right > self.x and left < self.right
        hits_top_pipe = top < self.gap_top
        hits_bottom_pipe = bottom > self.gap_bottom
        return overlaps_x and (hits_top_pipe or hits_bottom_pipe)

    def is_passed_by(self, bird):
        return not self.scored and self.right < bird.x
