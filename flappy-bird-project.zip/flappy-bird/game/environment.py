"""Headless-capable, step-based Flappy Bird simulation environment."""

import random

from .bird import Bird
from .pipe import Pipe


class FlappyBirdEnvironment:
    """
    A single independent game simulation.

    Actions:
        0: do nothing
        1: jump

    Observation (five floats):
        [0] bird_y: bird center y / screen height, clipped to [0, 1]
        [1] bird_velocity: vertical velocity / max_velocity, clipped to [-1, 1]
        [2] pipe_distance: distance from bird center to next pipe's left edge /
                          screen width, clipped to [0, 1]
        [3] gap_center_y: next gap center y / screen height, clipped to [0, 1]
        [4] gap_height: next gap height / screen height, clipped to [0, 1]

    y coordinates increase downward. The normalized values are dimensionless.
    Rewards:
        +1.0 when the bird passes a pipe pair; -1.0 on death.
         0.0 otherwise. A death transition may include a pipe reward if both
         events occur on the same step; collision takes precedence for the
         terminated state.
    """

    def __init__(
        self,
        width=480,
        height=640,
        seed=None,
        render_mode=None,
        pipe_speed=3.0,
        pipe_gap=170,
        pipe_width=72,
        pipe_spacing=220,
        max_steps=None,
    ):
        if width <= 0 or height <= 0:
            raise ValueError("width and height must be positive")
        if render_mode not in (None, "human"):
            raise ValueError("render_mode must be None or 'human'")
        self.width = int(width)
        self.height = int(height)
        self.render_mode = render_mode
        self.pipe_speed = float(pipe_speed)
        self.pipe_gap = int(pipe_gap)
        self.pipe_width = int(pipe_width)
        self.pipe_spacing = int(pipe_spacing)
        self.max_steps = max_steps
        self.rng = random.Random(seed)
        self._seed = seed
        self.renderer = None
        self.steps = 0
        self.score = 0
        self.terminated = False
        self.truncated = False
        self.bird = None
        self.pipes = []
        self.reset(seed=seed)

    def reset(self, seed=None):
        """Reset the episode and return (observation, info)."""
        if seed is not None:
            self.rng.seed(seed)
        self.steps = 0
        self.score = 0
        self.terminated = False
        self.truncated = False
        self.bird = Bird(x=self.width * 0.25, y=self.height * 0.5)
        self.pipes = []
        self._add_pipe(self.width + 80)
        self._add_pipe(self.width + 80 + self.pipe_spacing)
        return self.get_observation(), {"score": self.score, "steps": self.steps}

    def _add_pipe(self, x):
        margin = max(45, self.pipe_gap // 2 + 15)
        low = margin
        high = self.height - margin
        if low >= high:
            gap_y = self.height / 2
        else:
            gap_y = self.rng.randint(low, high)
        self.pipes.append(
            Pipe(x, gap_y, self.pipe_gap, self.pipe_width,
                 self.height, self.pipe_speed)
        )

    def _next_pipe(self):
        for pipe in self.pipes:
            if pipe.right >= self.bird.x:
                return pipe
        # This fallback is used only during a brief pipe-replacement boundary.
        return min(self.pipes, key=lambda pipe: pipe.x)

    def get_observation(self):
        """Return the current five-value observation as a tuple of floats."""
        pipe = self._next_pipe()
        max_velocity = 12.0
        return (
            self._clip(self.bird.y / self.height, 0.0, 1.0),
            self._clip(self.bird.velocity_y / max_velocity, -1.0, 1.0),
            self._clip((pipe.x - self.bird.x) / self.width, 0.0, 1.0),
            self._clip(pipe.gap_y / self.height, 0.0, 1.0),
            self._clip(pipe.gap_size / self.height, 0.0, 1.0),
        )

    @staticmethod
    def _clip(value, low, high):
        return max(low, min(high, value))

    def step(self, action):
        """
        Advance exactly one simulation frame.

        Returns (observation, reward, terminated, truncated, info).
        Raises ValueError for actions other than integer 0 or 1.
        """
        if isinstance(action, bool) or action not in (0, 1):
            raise ValueError("action must be 0 (do nothing) or 1 (jump)")
        if self.terminated or self.truncated:
            raise RuntimeError("Episode has ended. Call reset() before step().")

        self.steps += 1
        if action == 1:
            self.bird.jump()

        self.bird.update()
        for pipe in self.pipes:
            pipe.update()

        reward = 0.0
        for pipe in self.pipes:
            if pipe.is_passed_by(self.bird):
                pipe.scored = True
                self.score += 1
                reward += 1.0

        collision = (
            self.bird.y - self.bird.radius <= 0
            or self.bird.y + self.bird.radius >= self.height
            or any(pipe.collides_with_circle(self.bird) for pipe in self.pipes)
        )

        # Remove pipes that have fully left the screen and replenish the queue.
        self.pipes = [pipe for pipe in self.pipes if pipe.right >= 0]
        if self.pipes:
            rightmost = max(self.pipes, key=lambda pipe: pipe.x)
            if rightmost.x <= self.width - self.pipe_spacing:
                self._add_pipe(rightmost.x + self.pipe_spacing)
        else:
            self._add_pipe(self.width + 80)

        if collision:
            self.terminated = True
            reward -= 1.0

        if self.max_steps is not None and self.steps >= self.max_steps and not self.terminated:
            self.truncated = True

        info = {
            "score": self.score,
            "steps": self.steps,
            "collision": collision,
        }
        return self.get_observation(), reward, self.terminated, self.truncated, info

    def render(self):
        """Draw the current state. Rendering is initialized lazily."""
        if self.render_mode != "human":
            return
        if self.renderer is None:
            from .renderer import Renderer
            self.renderer = Renderer(self.width, self.height)
        self.renderer.draw(self)

    def close(self):
        """Close this environment's renderer, if it was created."""
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None
