"""Bird physics. Coordinates use pixels; positive y points downward."""


class Bird:
    def __init__(self, x, y, radius=16, gravity=0.48, jump_velocity=-8.5):
        self.x = float(x)
        self.y = float(y)
        self.radius = radius
        self.gravity = float(gravity)
        self.jump_velocity = float(jump_velocity)
        self.velocity_y = 0.0

    def reset(self, y):
        self.y = float(y)
        self.velocity_y = 0.0

    def jump(self):
        self.velocity_y = self.jump_velocity

    def update(self):
        self.velocity_y += self.gravity
        self.y += self.velocity_y

    @property
    def bounds(self):
        return (
            self.x - self.radius,
            self.y - self.radius,
            self.x + self.radius,
            self.y + self.radius,
        )
