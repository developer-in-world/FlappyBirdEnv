"""Flappy Bird-style game and reusable simulation environment."""

from .environment import FlappyBirdEnvironment

__all__ = ["FlappyBirdEnvironment"]
