"""Pygame rendering only; it does not update game physics."""

import pygame


class Renderer:
    def __init__(self, width, height):
        pygame.init()
        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Flappy Bird - Learning Environment")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 25)

    def draw(self, environment):
        self.screen.fill((115, 195, 225))

        # Simple background clouds.
        for x, y in ((75, 105), (300, 155), (410, 75)):
            pygame.draw.circle(self.screen, (235, 247, 245), (x, y), 19)
            pygame.draw.circle(self.screen, (235, 247, 245), (x + 20, y + 5), 15)
            pygame.draw.circle(self.screen, (235, 247, 245), (x - 17, y + 8), 13)

        for pipe in environment.pipes:
            green = (55, 165, 85)
            pygame.draw.rect(
                self.screen, green,
                (int(pipe.x), 0, pipe.width, int(pipe.gap_top))
            )
            pygame.draw.rect(
                self.screen, green,
                (int(pipe.x), int(pipe.gap_bottom), pipe.width,
                 self.height - int(pipe.gap_bottom))
            )
            pygame.draw.rect(
                self.screen, (35, 125, 65),
                (int(pipe.x) - 4, int(pipe.gap_top) - 14,
                 pipe.width + 8, 14)
            )
            pygame.draw.rect(
                self.screen, (35, 125, 65),
                (int(pipe.x) - 4, int(pipe.gap_bottom),
                 pipe.width + 8, 14)
            )

        # Ground strip.
        pygame.draw.rect(self.screen, (215, 190, 105),
                         (0, self.height - 22, self.width, 22))
        pygame.draw.line(self.screen, (130, 105, 65),
                         (0, self.height - 22), (self.width, self.height - 22), 3)

        bird = environment.bird
        pygame.draw.circle(self.screen, (255, 215, 65),
                           (int(bird.x), int(bird.y)), bird.radius)
        pygame.draw.circle(self.screen, (190, 125, 30),
                           (int(bird.x), int(bird.y)), bird.radius, 2)
        pygame.draw.circle(self.screen, (255, 255, 255),
                           (int(bird.x + 6), int(bird.y - 5)), 5)
        pygame.draw.circle(self.screen, (25, 25, 25),
                           (int(bird.x + 8), int(bird.y - 5)), 2)
        pygame.draw.polygon(
            self.screen, (235, 115, 45),
            [(int(bird.x + 12), int(bird.y + 1)),
             (int(bird.x + 25), int(bird.y + 5)),
             (int(bird.x + 12), int(bird.y + 8))]
        )

        score_surface = self.font.render(f"Score: {environment.score}", True, (25, 45, 55))
        self.screen.blit(score_surface, (15, 15))

        if environment.terminated:
            self._center_text("GAME OVER", self.font, self.height // 2 - 20)
            self._center_text("Press R to restart", self.small_font, self.height // 2 + 18)
        pygame.display.flip()

    def draw_start_screen(self):
        self.screen.fill((115, 195, 225))
        self._center_text("FLAPPY BIRD", self.font, self.height // 2 - 45)
        self._center_text("Press SPACE to start", self.small_font, self.height // 2)
        self._center_text("SPACE: jump   ESC: quit", self.small_font, self.height // 2 + 35)
        pygame.display.flip()

    def _center_text(self, text, font, y):
        surface = font.render(text, True, (25, 45, 55))
        rect = surface.get_rect(center=(self.width // 2, y))
        self.screen.blit(surface, rect)

    def tick(self, fps=60):
        self.clock.tick(fps)

    def close(self):
        pygame.display.quit()
        pygame.quit()
